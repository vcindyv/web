//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// DATABASE.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_DATABASE_FORM               101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_DATABASETYPE                130
#define IDB_BITMAP1                     311
#define IDB_BITMAP2                     313
#define IDC_LIST1                       1000
#define IDC_EDIT_NAME                   1002
#define IDC_EDIT_EMAIL                  1003
#define IDC_EDIT_PHONE                  1004
#define IDC_EDIT_FAM                    1005
#define IDC_BUTTON_Total                1006
#define IDC_BUTTON_ADD                  1007
#define IDC_BUTTON_UPDATE               1008
#define IDC_BUTTON_DELETE               1009
#define IDC_BUTTON_CANCEL               1010
#define IDC_BUTTON_SEARCH               1011
#define IDC_COMBO1                      1012
#define IDC_LIST2                       1013
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define IDM_ICON                        32775
#define IDM_SMALL_ICON                  32776
#define IDM_LIST                        32777
#define IDM_REPORT                      32778
#define ID_BUTTON32783                  32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
