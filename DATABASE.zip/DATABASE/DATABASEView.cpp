
// DATABASEView.cpp : CDATABASEView Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "DATABASE.h"
#endif

#include "DATABASESet.h"
#include "DATABASEDoc.h"
#include "DATABASEView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDATABASEView

IMPLEMENT_DYNCREATE(CDATABASEView, CRecordView)

BEGIN_MESSAGE_MAP(CDATABASEView, CRecordView)
	// ǥ�� �μ� �����Դϴ�.
	ON_COMMAND(ID_FILE_PRINT, &CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CRecordView::OnFilePrintPreview)
	ON_COMMAND(ID_RECORD_FIRST, &CDATABASEView::OnRecordFirst)
	ON_COMMAND(ID_RECORD_LAST, &CDATABASEView::OnRecordLast)
	ON_COMMAND(ID_RECORD_NEXT, &CDATABASEView::OnRecordNext)
	ON_COMMAND(ID_RECORD_PREV, &CDATABASEView::OnRecordPrev)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CDATABASEView::OnBnClickedButtonCancel)
	ON_BN_CLICKED(IDC_BUTTON_Total, &CDATABASEView::OnBnClickedButtonTotal)
	ON_BN_CLICKED(IDC_BUTTON_ADD, &CDATABASEView::OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_UPDATE, &CDATABASEView::OnBnClickedButtonUpdate)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, &CDATABASEView::OnBnClickedButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, &CDATABASEView::OnBnClickedButtonSearch)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST1, &CDATABASEView::OnLvnItemchangedList1)
	ON_WM_MOUSEMOVE()
	ON_CBN_SELCHANGE(IDC_COMBO1, &CDATABASEView::OnCbnSelchangeCombo1)
	ON_COMMAND(IDM_ICON, &CDATABASEView::OnIcon)
	ON_COMMAND(IDM_SMALL_ICON, &CDATABASEView::OnSmallIcon)
	ON_COMMAND(IDM_LIST, &CDATABASEView::OnList)
	ON_COMMAND(IDM_REPORT, &CDATABASEView::OnReport)
END_MESSAGE_MAP()

// CDATABASEView ����/�Ҹ�

CDATABASEView::CDATABASEView(): CRecordView(IDD_DATABASE_FORM)
{
	m_pSet = NULL;
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.
	current_pos = 1;
	record_count = 0;
	bAdd = FALSE;
	bUpdate = FALSE;
	bSearch = FALSE;
}

CDATABASEView::~CDATABASEView()
{
}

void CDATABASEView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	// ��Ʈ���� �����ͺ��̽� �ʵ忡 '����'�ϱ� ���� ���⿡ DDX_Field* �Լ��� ������ �� �ֽ��ϴ�. ��:
	// DDX_FieldText(pDX, IDC_MYEDITBOX, m_pSet->m_szColumn1, m_pSet);
	// DDX_FieldCheck(pDX, IDC_MYCHECKBOX, m_pSet->m_bColumn2, m_pSet);
	// �ڼ��� ������ MSDN �� ODBC ������ �����Ͻʽÿ�.

	DDX_FieldText(pDX, IDC_EDIT_NAME, m_pSet->m_tname, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_EMAIL, m_pSet->m_temail, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_PHONE, m_pSet->m_tphone, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_FAM, m_pSet->m_tgroup, m_pSet);
	//DDX_FieldText(pDX, IDC_EDIT_RERATION, m_pSet->m_trelation, m_pSet);




	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Control(pDX, IDC_EDIT_NAME, m_EditName);
	DDX_Control(pDX, IDC_EDIT_EMAIL, m_EditEmail);
	DDX_Control(pDX, IDC_EDIT_PHONE, m_EditPhone);
	DDX_Control(pDX, IDC_EDIT_FAM, m_EditFam);
	DDX_Control(pDX, IDC_BUTTON_Total, m_ButtonTotal);
	DDX_Control(pDX, IDC_BUTTON_ADD, m_ButtonAdd);
	DDX_Control(pDX, IDC_BUTTON_UPDATE, m_ButtonUpdate);
	DDX_Control(pDX, IDC_BUTTON_DELETE, m_ButtonDelete);
	DDX_Control(pDX, IDC_BUTTON_CANCEL, m_ButtonCancel);
//	DDX_Control(pDX, IDC_BUTTON1, m_ButtonSearch);
	DDX_Control(pDX, IDC_BUTTON_SEARCH, m_ButtonSearch);
	DDX_Control(pDX, IDC_COMBO1, m_Combo);
}

BOOL CDATABASEView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CRecordView::PreCreateWindow(cs);
}

void CDATABASEView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_DATABASESet;
	CRecordView::OnInitialUpdate();
	AddColumn();
	SetImageList();
	AddAllRecord();
	GetTotalRecordCount();

}


// CDATABASEView �μ�

BOOL CDATABASEView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// �⺻���� �غ�
	return DoPreparePrinting(pInfo);
}

void CDATABASEView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ��ϱ� ���� �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
}

void CDATABASEView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ� �� ���� �۾��� �߰��մϴ�.
}


// CDATABASEView ����

#ifdef _DEBUG
void CDATABASEView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CDATABASEView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CDATABASEDoc* CDATABASEView::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDATABASEDoc)));
	return (CDATABASEDoc*)m_pDocument;
}
#endif //_DEBUG


// CDATABASEView �����ͺ��̽� ����
CRecordset* CDATABASEView::OnGetRecordset()
{
	return m_pSet;
}



// CDATABASEView �޽��� ó����


void CDATABASEView::AddColumn()
{
	CRect rect;
	m_List.GetClientRect(&rect);


	m_List.InsertColumn(0, _T("�̸�"), LVCFMT_RIGHT, 80);
	m_List.InsertColumn(1, _T("�̸���"), LVCFMT_LEFT, 180);
	m_List.InsertColumn(2, _T("��ȭ��ȣ"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(3, _T("����"), LVCFMT_LEFT, 100);
	m_List.InsertColumn(4, _T("����"), LVCFMT_LEFT, 100);
	


}


void CDATABASEView::SetImageList()
{
	
	m_SmallImageList.Create(IDB_BITMAP1, 16, 1, RGB(0, 0, 0));
	m_List.SetImageList(&m_SmallImageList, LVSIL_SMALL);
	
	m_LargeImageList.Create(IDB_BITMAP2, 48, 1, RGB(0, 0, 0));
	m_List.SetImageList(&m_LargeImageList, LVSIL_NORMAL);

}

#include "DATABASESet.h"
void CDATABASEView::AddAllRecord()
{
	CDATABASESet reSet(m_pSet->m_pDatabase);
	reSet.Open(CRecordset::dynaset, _T("select * from addressbook"));
	m_List.DeleteAllItems();

	int i = 0;
	CString strTemp;

	while (reSet.IsEOF() == FALSE) {
		strTemp.Format(_T("%s"), reSet.m_tname);
		m_List.InsertItem(i, strTemp, 0);
		
		m_List.SetItemText(i, 1, reSet.m_temail);
		m_List.SetItemText(i, 2, reSet.m_tphone);
		m_List.SetItemText(i, 3, reSet.m_tgroup);
		m_List.SetItemText(i, 4, reSet.m_trelation);
		reSet.MoveNext();
		i++;
	}
	reSet.Close();
}


void CDATABASEView::GetTotalRecordCount()
{
	CRecordset cntSet(m_pSet->m_pDatabase);
	cntSet.Open(CRecordset::dynaset, _T("select count(*)from addressbook"));
	CString strCount;
	cntSet.GetFieldValue((short)0, strCount);
	record_count = atoi((char *)(const wchar_t*)strCount);
	cntSet.Close();

}


void CDATABASEView::OnRecordFirst()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	if (record_count == 0) return;
	current_pos = 1;
	m_pSet->MoveFirst();
	UpdateData(FALSE);
}


void CDATABASEView::OnRecordLast()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	if (record_count == 0) return;
	
	current_pos = record_count;
	m_pSet->MoveLast();
	UpdateData(FALSE);
}


void CDATABASEView::OnRecordNext()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	if (record_count == 0) return;
	current_pos ++;
	m_pSet->MoveNext();
	if (m_pSet->IsEOF()) {
		m_pSet->MoveLast();
		current_pos--;
}
	UpdateData(FALSE);
}


void CDATABASEView::OnRecordPrev()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	if (record_count == 0) return;
	current_pos--;
	m_pSet->MovePrev();
	if (m_pSet->IsBOF()) {
		m_pSet->MoveFirst();
		current_pos=1;
	}
	
	
	UpdateData(FALSE);
}


void CDATABASEView::Init()
{
	m_EditName.EnableWindow(0);
	m_EditEmail.EnableWindow(0);
	m_EditPhone.EnableWindow(0);
	m_EditFam.EnableWindow(0);

	m_ButtonTotal.EnableWindow(1);
	m_ButtonAdd.EnableWindow(1);
	m_ButtonUpdate.EnableWindow(1);
	m_ButtonDelete.EnableWindow(1);
	m_ButtonCancel.EnableWindow(1);
}


void CDATABASEView::Clear()
{
	m_EditName.EnableWindow(1);
	m_EditEmail.EnableWindow(1);
	m_EditPhone.EnableWindow(1);
	m_EditFam.EnableWindow(1);

	m_ButtonTotal.EnableWindow(0);
	m_ButtonAdd.EnableWindow(0);
	m_ButtonUpdate.EnableWindow(0);
	m_ButtonDelete.EnableWindow(0);
	m_ButtonCancel.EnableWindow(0);

}


void CDATABASEView::OnBnClickedButtonCancel()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (bAdd) {
		m_pSet->SetAbsolutePosition(current_pos);
		UpdateData(FALSE);
		bAdd = FALSE;
	}
	if (bUpdate) {
		m_pSet->SetAbsolutePosition(current_pos);
		UpdateData(FALSE);
		bUpdate = FALSE;
	}
	if (bSearch) {
		m_pSet->SetAbsolutePosition(current_pos);
		UpdateData(FALSE);
		bSearch = FALSE;
	}
	Init();

}



void CDATABASEView::OnBnClickedButtonTotal()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	Init();
	AddAllRecord();
}


void CDATABASEView::OnBnClickedButtonAdd()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	bAdd = !bAdd;
	if (bAdd == TRUE) {
		m_pSet->AddNew();
		m_pSet->SetFieldNull(NULL);
		UpdateData(FALSE);
		Clear();
		m_ButtonAdd.EnableWindow(1);
		m_EditName.SetFocus();
	}
	else {
		UpdateData(TRUE);
		m_pSet->Update();
		m_pSet->Requery();

		m_pSet->MoveLast();
		GetTotalRecordCount();
		UpdateData(FALSE);
		Init();
		AddAllRecord();
	}
}


void CDATABASEView::OnBnClickedButtonUpdate()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	bUpdate = !bUpdate;

	if (bUpdate == TRUE) {
		m_pSet->SetAbsolutePosition(current_pos);
		UpdateData(FALSE);
		Clear();
		m_ButtonUpdate.EnableWindow(1);
	}
	else {
		m_pSet->Edit();
		UpdateData(TRUE);

		m_pSet->Update();
		m_pSet->Requery();

		m_pSet->SetAbsolutePosition(current_pos);
		UpdateData(FALSE);

		Init();
		AddAllRecord();
	}
}


void CDATABASEView::OnBnClickedButtonDelete()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if (record_count == 0) {
		MessageBox(_T("������ �����Ͱ� �����ϴ�!"));
		return;
	}
	m_pSet->Delete();
	m_pSet->Requery();

	GetTotalRecordCount();

	if (record_count == 0) {
		m_pSet->SetFieldNull(NULL);
		UpdateData(FALSE);
		current_pos = 0;
		return;
	}
	if (record_count < current_pos)
		current_pos--;

	m_pSet->SetAbsolutePosition(current_pos);
	UpdateData(FALSE);
	AddAllRecord();
}


void CDATABASEView::OnBnClickedButtonSearch()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	bSearch = !bSearch;
	if (bSearch) {
		m_EditName.SetWindowTextW(_T(""));
		m_EditEmail.SetWindowTextW(_T(""));
		m_EditPhone.SetWindowTextW(_T(""));
		m_EditFam.SetWindowTextW(_T(""));

		Clear();
		m_EditEmail.EnableWindow(0);
		m_EditPhone.EnableWindow(0);
		m_EditFam.EnableWindow(0);
		m_ButtonSearch.EnableWindow(1);
		m_EditName.SetFocus();

	}
	else {
		UpdateData(true);
		CDATABASESet rsSet(m_pSet->m_pDatabase);
		CString sql;

		if (m_pSet->m_tname.IsEmpty() == false) {
			sql.Format(_T("select * from addressbook where tname like '%%%s%%'"), m_pSet->m_tname);
			rsSet.Open(CRecordset::dynaset, sql);

			
			m_List.DeleteAllItems();
			int i = 0;

			CString strTemp;
			while (rsSet.IsEOF() == FALSE) {
		
				strTemp.Format(_T("%s"), rsSet.m_tname);
				m_List.InsertItem(i, strTemp, 0);
		
				m_List.SetItemText(i, 1, rsSet.m_temail);
				m_List.SetItemText(i, 2, rsSet.m_tphone);
				m_List.SetItemText(i, 3, rsSet.m_tgroup);
				m_List.SetItemText(i, 4, rsSet.m_trelation);
				rsSet.MoveNext();
				i++;
			}
			rsSet.Close();
			Init();
		}
		
	}
}



#include "MainFrm.h"
void CDATABASEView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CString msg;
	msg.Format(_T("2016152025 �����"));
	CMainFrame *pFrame = (CMainFrame*)AfxGetMainWnd();
	pFrame->GetStatusBar()->SetPaneText(2, msg);
	CRecordView::OnMouseMove(nFlags, point);
}





void CDATABASEView::OnIcon()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.

	m_List.ModifyStyle(LVS_TYPEMASK, LVS_ICON);
}


void CDATABASEView::OnSmallIcon()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_List.ModifyStyle(LVS_TYPEMASK, LVS_SMALLICON);
}


void CDATABASEView::OnList()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_List.ModifyStyle(LVS_TYPEMASK, LVS_LIST);
}


void CDATABASEView::OnReport()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_List.ModifyStyle(LVS_TYPEMASK, LVS_REPORT);
}

void CDATABASEView::OnLvnItemchangedList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	int nItem = pNMLV->iItem;
	current_pos = nItem + 1;
	m_pSet->SetAbsolutePosition(current_pos);

	CString strName, sql, strTemp;
	strName = m_List.GetItemText(nItem, 0);

	sql.Format(_T("select * from addressbook where tname = %s "), strName);
	CDATABASESet rsSet(m_pSet->m_pDatabase);
	rsSet.Open(CRecordset::dynaset, sql);


	m_EditEmail.SetWindowTextW(rsSet.m_temail);
	m_EditPhone.SetWindowTextW(rsSet.m_tphone);
	m_EditFam.SetWindowTextW(rsSet.m_tgroup);

	
	*pResult = 0;


	
	
	
}

void CDATABASEView::OnCbnSelchangeCombo1()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CString sql;
	CDATABASESet rsSet(m_pSet->m_pDatabase);
	int nIndex = m_Combo.GetCurSel();
	int i = 0;
	CString strTemp;
	if (m_pSet->m_tname.IsEmpty() == false) {

		switch (nIndex)
		{
		case 0: {
			sql.Format(_T("select * from addressbook where trelation like '%%%s%%'"), (_T("����")));//m_pSet->m_trelation
			rsSet.Open(CRecordset::dynaset, sql);
			m_List.DeleteAllItems();
			
			while (rsSet.IsEOF() == FALSE) {

				strTemp.Format(_T("%s"), rsSet.m_tname);
				m_List.InsertItem(i, strTemp, 0);
				m_List.SetItemText(i, 1, rsSet.m_temail);
				m_List.SetItemText(i, 2, rsSet.m_tphone);
				m_List.SetItemText(i, 3, rsSet.m_tgroup);
				m_List.SetItemText(i, 4, rsSet.m_trelation);
				rsSet.MoveNext();
				i++;
			}
			rsSet.Close();
			Init();
		}break;
		case 1: {
			sql.Format(_T("select * from addressbook where trelation like '%%%s%%'"), (_T("����")));//m_pSet->m_trelation
			rsSet.Open(CRecordset::dynaset, sql);
			m_List.DeleteAllItems();

			while (rsSet.IsEOF() == FALSE) {

				strTemp.Format(_T("%s"), rsSet.m_tname);
				m_List.InsertItem(i, strTemp, 0);
				m_List.SetItemText(i, 1, rsSet.m_temail);
				m_List.SetItemText(i, 2, rsSet.m_tphone);
				m_List.SetItemText(i, 3, rsSet.m_tgroup);
				m_List.SetItemText(i, 4, rsSet.m_trelation);
				rsSet.MoveNext();
				i++;
			}
			rsSet.Close();
			Init();
		}break;
		case 2: {
			sql.Format(_T("select * from addressbook where trelation like '%%%s%%'"), (_T("�б�")));//m_pSet->m_trelation
			rsSet.Open(CRecordset::dynaset, sql);
			m_List.DeleteAllItems();

			while (rsSet.IsEOF() == FALSE) {

				strTemp.Format(_T("%s"), rsSet.m_tname);
				m_List.InsertItem(i, strTemp, 0);
				m_List.SetItemText(i, 1, rsSet.m_temail);
				m_List.SetItemText(i, 2, rsSet.m_tphone);
				m_List.SetItemText(i, 3, rsSet.m_tgroup);
				m_List.SetItemText(i, 4, rsSet.m_trelation);
				rsSet.MoveNext();
				i++;
			}
			rsSet.Close();
			Init();
		}break;
		case 3: {
			sql.Format(_T("select * from addressbook where trelation like '%%%s%%'"), (_T("ģ��")));//m_pSet->m_trelation
			rsSet.Open(CRecordset::dynaset, sql);
			m_List.DeleteAllItems();

			while (rsSet.IsEOF() == FALSE) {

				strTemp.Format(_T("%s"), rsSet.m_tname);
				m_List.InsertItem(i, strTemp, 0);
				m_List.SetItemText(i, 1, rsSet.m_temail);
				m_List.SetItemText(i, 2, rsSet.m_tphone);
				m_List.SetItemText(i, 3, rsSet.m_tgroup);
				m_List.SetItemText(i, 4, rsSet.m_trelation);
				rsSet.MoveNext();
				i++;
			}
			rsSet.Close();
			Init();
		}break;
		case 4: {
			sql.Format(_T("select * from addressbook where trelation like '%%%s%%'"), (_T("��Ÿ")));//m_pSet->m_trelation
			rsSet.Open(CRecordset::dynaset, sql);
			m_List.DeleteAllItems();

			while (rsSet.IsEOF() == FALSE) {

				strTemp.Format(_T("%s"), rsSet.m_tname);
				m_List.InsertItem(i, strTemp, 0);
				m_List.SetItemText(i, 1, rsSet.m_temail);
				m_List.SetItemText(i, 2, rsSet.m_tphone);
				m_List.SetItemText(i, 3, rsSet.m_tgroup);
				m_List.SetItemText(i, 4, rsSet.m_trelation);
				rsSet.MoveNext();
				i++;
			}
			rsSet.Close();
			Init();
		}break;
		case 5: {
			sql.Format(_T("select * from addressbook where trelation like '%%%s%%'"), (_T("��ü")));//m_pSet->m_trelation
			OnBnClickedButtonTotal();
		}break;




		}
	}
}