
// DATABASEView.h : CDATABASEView Ŭ������ �������̽�
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

class CDATABASESet;

class CDATABASEView : public CRecordView
{
	BOOL bAdd;
	BOOL bUpdate;
	BOOL bSearch;
	
	int current_pos;
	int record_count;
	CImageList m_SmallImageList;
	CImageList m_LargeImageList;
protected: // serialization������ ��������ϴ�.
	CDATABASEView();
	DECLARE_DYNCREATE(CDATABASEView)

public:
#ifdef AFX_DESIGN_TIME
	enum{ IDD = IDD_DATABASE_FORM };
#endif
	CDATABASESet* m_pSet;

// Ư���Դϴ�.
public:
	CDATABASEDoc* GetDocument() const;

// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual void OnInitialUpdate(); // ���� �� ó�� ȣ��Ǿ����ϴ�.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// �����Դϴ�.
public:
	virtual ~CDATABASEView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ������ �޽��� �� �Լ�
protected:
	DECLARE_MESSAGE_MAP()
public:

	CListCtrl m_List;
	CEdit m_EditName;
	CEdit m_EditEmail;
	CEdit m_EditPhone;
	CEdit m_EditFam;
	CButton m_ButtonTotal;
	CButton m_ButtonAdd;
	CButton m_ButtonUpdate;
	CButton m_ButtonDelete;
	CButton m_ButtonCancel;
	void AddColumn();
	void SetImageList();
	void AddAllRecord();
	void GetTotalRecordCount();
	afx_msg void OnRecordFirst();
	afx_msg void OnRecordLast();
	afx_msg void OnRecordNext();
	afx_msg void OnRecordPrev();
	void Init();
	void Clear();
	afx_msg void OnBnClickedButtonCancel();
	afx_msg void OnBnClickedButtonTotal();
	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonUpdate();
	afx_msg void OnBnClickedButtonDelete();
	
	CButton m_ButtonSearch;
	afx_msg void OnBnClickedButtonSearch();
	afx_msg void OnLvnItemchangedList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	CComboBox m_Combo;
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnIcon();
	afx_msg void OnSmallIcon();
	afx_msg void OnList();
	afx_msg void OnReport();
};

#ifndef _DEBUG  // DATABASEView.cpp�� ����� ����
inline CDATABASEDoc* CDATABASEView::GetDocument() const
   { return reinterpret_cast<CDATABASEDoc*>(m_pDocument); }
#endif

